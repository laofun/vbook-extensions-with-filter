let BASE_URL = "https://tytnovel.xyz";
let BASE_HOST = "https://api.noveltyt.xyz";
let BASE_TOKEN = "14cbab00043f7d1a89a89fde7f7c80f24d7bff693e23880298d3e670db9a680a";
let BASE_USER = "66d95cf231c59f350f798376";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}