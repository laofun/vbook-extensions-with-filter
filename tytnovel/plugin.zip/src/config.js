let BASE_URL = "https://tytnovel.xyz";
let BASE_HOST = "https://api.noveltyt.xyz";
let BASE_TOKEN = "c8433c0dbef937654e982d076e4f4320b71ab3d2c32d7329ec48b120dacc1f37";
let BASE_USER = "66d95cf231c59f350f798376";
let BASE_VERSION = "80";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}