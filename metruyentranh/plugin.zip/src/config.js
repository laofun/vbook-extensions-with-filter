let BASE_URL = 'https://metruyentranh.pro';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}